package org.physical_web.physicalweb;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * Basic application test.
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}
