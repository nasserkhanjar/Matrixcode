# Android client

This Android client can be downloaded from the [Google Play store](https://play.google.com/store/apps/details?id=physical_web.org.physicalweb). A walkthrough of the app [is here](http://github.com/google/physical-web/blob/master/documentation/android_client_walkthrough.md) and will show you how to put your URL into a beacon.

Keep in mind that this software is just a prototype. We are doing it this way to easily and quickly test the concept. Eventually, the goal is to have this Physical Web code rolled into each browser.