# iOS client

This iOS client can be downloaded from the [Apple App Store](https://itunes.apple.com/us/app/physical-web/id927653608?mt=8). A walkthrough of the app [is here](http://github.com/google/physical-web/blob/master/documentation/android_client_walkthrough.md) (Android version) and will show you how to put your URL into a beacon.

Keep in mind that this software is just a prototype. We are doing it this way to easily and quickly test the concept. Eventually, the goal is to have this Physical Web code rolled into each browser.