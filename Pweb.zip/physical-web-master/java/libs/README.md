# Physical Web Collection library for java

This java library contains data structures and convenience utilities for
storing metadata related to devices that broadcast URLs.  This library is
intended to help bootstrap new Physical Web clients written in java.
