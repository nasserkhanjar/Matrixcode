## node-eddystone-beacon-scanner

There is an excellent node.js scanner module written by [@sandeepmistry](https://github.com/sandeepmistry). If you'd like to build a RasperryPi/laptop client to scan for beacons, please use this.

[node-eddystone-beacon-scanner](https://github.com/sandeepmistry/node-eddystone-beacon-scanner)

## physical-web-scan

If you don't want to build your own client, you can use this for Mac OSX. It fetches metadata from the [Physical Web Service](../web-service) and displays found beacons in both the terminal and notification center.

[physical-web-scan](https://github.com/dermike/physical-web-scan)
